# AI Text Summarization Platform

This is a comprehensive text summarization platform built with Python Flask. It allows users to summarize content from various sources including PDF, DOCX, TXT files, URLs, YouTube videos, and manual text input.

## Features

- Multi-format document summarization (PDF, DOCX, TXT)
- URL and YouTube video summarization
- Customizable compression ratios
- Multiple output formats (bullet points, paragraphs, plain text)
- Export options (TXT, DOCX, PDF)
- User authentication system
- Performance metrics (ROUGE score, compression ratio)
- AI chatbot assistant

## Installation

1. Clone the repository:
   \`\`\`
   git clone <repository-url>
   cd text-summarization-platform
   \`\`\`

2. Create a virtual environment:
   \`\`\`
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   \`\`\`

3. Install the dependencies:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

4. Set up the .env file:
   \`\`\`
   SECRET_KEY=your_secret_key_here
   \`\`\`

5. Initialize the database:
   \`\`\`
   python
   >>> from app import app, db
   >>> with app.app_context():
   >>>     db.create_all()
   >>> exit()
   \`\`\`

6. Run the application:
   \`\`\`
   python app.py
   \`\`\`

7. Access the application in your web browser at:
   \`\`\`
   http://127.0.0.1:5000/
   \`\`\`

## Usage

1. Register for an account or log in
2. Navigate to the Summarize page
3. Choose your input source (file, URL, YouTube, text)
4. Adjust the compression ratio as needed
5. Select your preferred view type
6. Generate your summary
7. View, format, and export the summary as needed

## Dependencies

- Flask: Web framework
- SQLAlchemy: Database ORM
- NLTK: Natural language processing
- NetworkX: Graph-based algorithms
- BeautifulSoup: Web scraping
- PyPDF2 & python-docx: Document parsing
- YouTube Transcript API: YouTube video transcription
- FPDF: PDF generation

## License

MIT
