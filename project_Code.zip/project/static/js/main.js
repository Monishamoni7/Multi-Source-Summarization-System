// Wait for DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
  // Add button click effects
  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('mousedown', () => {
      button.style.transform = 'translateY(1px)';
    });
    
    button.addEventListener('mouseup', () => {
      button.style.transform = 'translateY(-2px)';
    });
    
    button.addEventListener('mouseleave', () => {
      button.style.transform = 'translateY(0)';
    });
  });

  // Chatbot functionality
  const chatbotIcon = document.getElementById("chatbotIcon")
  const chatbotWindow = document.getElementById("chatbotWindow")
  const closeChatbot = document.getElementById("closeChatbot")
  const chatbotMessages = document.getElementById("chatbotMessages")
  const chatbotInput = document.getElementById("chatbotInput")
  const sendChatbot = document.getElementById("sendChatbot")

  // Toggle chatbot window
  if (chatbotIcon) {
    chatbotIcon.addEventListener("click", () => {
      chatbotWindow.style.display = "flex"
      chatbotWindow.classList.add("fade-in")
      chatbotInput.focus()

      // Stop the pulse animation when opened
      chatbotIcon.style.animation = "none"
    })
  }

  // Close chatbot window
  if (closeChatbot) {
    closeChatbot.addEventListener("click", () => {
      chatbotWindow.style.display = "none"
    })
  }

  // Send message when button is clicked
  if (sendChatbot) {
    sendChatbot.addEventListener("click", sendMessage)
  }

  // Send message when Enter key is pressed
  if (chatbotInput) {
    chatbotInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        e.preventDefault()
        sendMessage()
      }
    })
  }

  // Function to send message to chatbot
  function sendMessage() {
    const message = chatbotInput.value.trim()

    if (message) {
      // Add user message to chat
      addMessage(message, "user")

      // Clear input
      chatbotInput.value = ""

      // Show typing indicator
      const typingIndicator = document.createElement("div")
      typingIndicator.classList.add("message", "bot", "typing-indicator")
      typingIndicator.innerHTML = `
        <div class="typing">
          <span></span>
          <span></span>
          <span></span>
        </div>
      `
      chatbotMessages.appendChild(typingIndicator)
      chatbotMessages.scrollTop = chatbotMessages.scrollHeight

      // Send message to backend
      fetch("/chatbot", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: message,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          // Remove typing indicator
          const typingIndicator = document.querySelector(".typing-indicator")
          if (typingIndicator) {
            typingIndicator.remove()
          }

          // Add bot response to chat
          addMessage(data.response, "bot")
        })
        .catch((error) => {
          console.error("Error sending message:", error)

          // Remove typing indicator
          const typingIndicator = document.querySelector(".typing-indicator")
          if (typingIndicator) {
            typingIndicator.remove()
          }

          addMessage("Sorry, I encountered an error. Please try again.", "bot")
        })
    }
  }

  // Function to add message to chat
  function addMessage(text, sender) {
    const messageElement = document.createElement("div")
    messageElement.classList.add("message", sender)

    // Format links in the text
    const formattedText = text.replace(
      /(https?:\/\/[^\s]+)/g,
      '<a href="$1" target="_blank" class="text-primary">$1</a>',
    )

    messageElement.innerHTML = `<p class="mb-0">${formattedText}</p>`

    chatbotMessages.appendChild(messageElement)

    // Scroll to bottom of messages
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight
  }

  // Add CSS for typing indicator
  const style = document.createElement("style")
  style.textContent = `
    .typing-indicator {
      background-color: transparent !important;
      box-shadow: none !important;
    }
    .typing {
      display: flex;
      align-items: center;
      column-gap: 6px;
      padding: 10px 15px;
      background: white;
      border-radius: 18px;
      border-bottom-left-radius: 5px;
      width: fit-content;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }
    .typing span {
      width: 8px;
      height: 8px;
      background: #3a6df0;
      border-radius: 50%;
      opacity: 0.4;
      animation: pulse 1s infinite;
    }
    .typing span:nth-child(1) {
      animation-delay: 0s;
    }
    .typing span:nth-child(2) {
      animation-delay: 0.2s;
    }
    .typing span:nth-child(3) {
      animation-delay: 0.4s;
    }
    @keyframes pulse {
      0%, 100% {
        opacity: 0.4;
        transform: scale(1);
      }
      50% {
        opacity: 1;
        transform: scale(1.2);
      }
    }
  `
  document.head.appendChild(style)

  // Initialize tooltips
  let bootstrap
  if (typeof bootstrap === "undefined") {
    bootstrap = window.bootstrap
  }
  if (typeof bootstrap !== "undefined") {
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
    const tooltipList = [...tooltipTriggerList].map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))
  }
})
